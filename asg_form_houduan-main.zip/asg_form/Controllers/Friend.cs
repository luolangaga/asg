﻿namespace asg_form.Controllers
{
    public class T_Friend
    {
        public long id {  get; set; }
        public string headName {  get; set; }
        public string comMsg {  get; set; }

        public string headTel {  get; set; }

        public string account {  get; set; }

        public DateTime comTime {  get; set; }
        public string comType {  get; set; }
        public string orgName { get; set; }

        public int degree {  get; set; }

    }
}
