﻿namespace asg_form.Controllers
{
   static class all
    {
        public static string 测试 { get; set; }
    }
}
