namespace asg_form
{
    public static class WeatherForecast
    {
        public static string? str { get; set; }
    }
}